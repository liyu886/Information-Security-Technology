#include<iostream>
#include<fstream>
#include<cstring>
using namespace std;

using namespace std;

void get_miwen(char* miwen);
int keyLength(char* miwen);
void get_key(int klen, char* miwen, char* keys);
void decode(char* mingwen, char* miwen, char* keys);
int main(){

    //输入密文
    char miwen[5000];
    get_miwen(miwen);

    //获取密钥长度
    int keys_len = keyLength(miwen);

    //进一步获得密钥
    char keys[keys_len];
    get_key(keys_len, miwen, keys);

    //根据密钥解密
    int len = strlen(miwen);
    char mingwen[len];

    decode(mingwen, miwen, keys);

    cout << "Keys:" ;
    for(int i = 0 ; i < keys_len; i++){
        cout << keys[i] ;
    }
    cout << endl;
    cout << "Mingwen is:" << endl;

    for(int i = 0; i < len; i++){
        cout << mingwen[i] ;
    }
    cout << endl;
    
    
    
}

//从文件中读取密文，只读取字母，若为小写字母也转成大写字母来读
void get_miwen(char miwen[]){
    ifstream infile;

    //infile.open("miwen.txt", ios::in);
    infile.open("miwen.txt", ios::in);
    if(!infile.is_open()){
        cout << "Open file error!" << endl;
        exit(0);
    }
    int i;
    for(i = 0; !infile.eof(); i++){
        char temp;
        infile >> temp;
        if(temp <= 'Z' && temp >= 'A'){
            miwen[i] = temp;
        } else if(temp <= 'z' && temp >= 'a'){
            miwen[i] = temp - ('a' - 'A');
        }
        
    }
    miwen[i] = '\0';
    infile.close();
}

int keyLength(char* miwen){
    int miwen_len = strlen(miwen);

    for(int m = 1; m < miwen_len; m++){
        double Ic[m]; //m个子串每个的重合因子

        for(int i = 0; i < m; i++){//m个子串都满足

            int sub_len = miwen_len / m; //子串的长度
            int f[26] = {0};//用于统计该子串每个字母出现的次数

            for(int j = 0; j < sub_len; j++){   //遍历该子串
                f[miwen[i + m * j] - 'A']++;
            }

            int total = 0;
            for(int j = 0; j < 26; j++){
                total += f[j] * (f[j] - 1);
            }

            Ic[i] = (double)total / (double)(sub_len * (sub_len - 1)) ;
        }

        double avg_Ic = 0.0;
        for(int i = 0; i < m; i++){
            avg_Ic += Ic[i];
        }
        avg_Ic /= m;

        if(avg_Ic >= 0.06){
            return m;
        }
    }
}

void get_key(int klen, char* miwen, char* keys){
    //26个字母出现的概率
    double p[26] = {0.082, 0.015, 0.028, 0.043, 0.127, 0.022, 0.02, 0.061, 0.07, 0.002, 0.008, 0.04, 0.024, 0.067, 0.075, 0.019, 0.001, 0.06, 0.063, 0.091, 0.028, 0.01, 0.023, 0.001, 0.02, 0.001};
    int sub_len = strlen(miwen) / klen;

    for(int i = 0; i < klen; i++){//对每个子串

        int f[26] = {0};//用于统计该子串每个字母出现的次数
        for(int j = 0; j < sub_len; j++){   //遍历该子串
            f[miwen[i + klen * j] - 'A']++;
        }

        double max = 0;
        
        for(int g = 0; g < 26; g++){//试偏移量
            double Mg = 0;
            for(int j = 0; j < 26; j++){
                Mg += ((double)p[j] * f[(j + g) % 26] / sub_len);
            }

            if(Mg > max){
                max = Mg;
                keys[i] = (char)'A' + g;
            }
        }
        
    }

    return ;
}


void decode(char* mingwen, char* miwen, char* keys){
    int key_len = strlen(keys);
    int sub_len = strlen(miwen) / key_len;


    for(int i = 0; i < strlen(miwen); i++){
        int temp =  miwen[i] + (keys[i % key_len] - 'A');
        int over = temp % ('Z' + 1);
        if(over == temp){
            mingwen[i] = (char)over;
        }else{
            mingwen[i] = (char)over + 'A';
        }

    }
}